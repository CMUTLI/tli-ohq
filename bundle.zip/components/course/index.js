module.exports.routes = require('./routes');
